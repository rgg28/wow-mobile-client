package app.gamenative.ui.screen.xserver

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.os.Build
import android.os.SystemClock
import android.util.Log
import android.view.Display
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.View.OnLayoutChangeListener
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.hardware.display.DisplayManager
import android.hardware.input.InputManager
import android.view.InputDevice
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import app.gamenative.BuildConfig
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import app.gamenative.MainActivity
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.Alignment
import androidx.compose.ui.input.pointer.PointerIcon
import androidx.compose.ui.input.pointer.pointerHoverIcon
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import app.gamenative.R
import app.gamenative.ui.util.SnackbarManager
import app.gamenative.ui.util.applyScreenEffectsConfig
import app.gamenative.ui.util.loadScreenEffectsConfig
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.compose.LocalLifecycleOwner
import app.gamenative.PluviaApp
import app.gamenative.PrefManager
import app.gamenative.data.GyroSettings
import app.gamenative.data.ShooterModeConfig
import app.gamenative.events.AndroidEvent
import app.gamenative.ui.enums.Orientation
import java.util.EnumSet
import app.gamenative.externaldisplay.ExternalDisplayInputController
import app.gamenative.externaldisplay.ExternalDisplaySwapController
import app.gamenative.externaldisplay.SwapInputOverlayView
import app.gamenative.ui.component.LsfgQuickMenuState
import app.gamenative.ui.component.PerformanceQuickMenuState
import app.gamenative.ui.component.QuickMenu
import app.gamenative.ui.component.QuickMenuAction
import app.gamenative.ui.component.parseBooleanExtra
import app.gamenative.ui.component.parsePositiveFpsLimit
import app.gamenative.ui.data.PerformanceHudConfig
import app.gamenative.ui.data.PerformanceHudSize
import app.gamenative.ui.widget.PerformanceHudView
import app.gamenative.utils.AssetUtils
import app.gamenative.utils.ContainerUtils
import app.gamenative.utils.downloader.CoreDriverDownloader
import app.gamenative.utils.LsfgQuickMenuHelper
import app.gamenative.utils.LsfgVkManager
import app.gamenative.utils.downloader.DXWrapperDownloader
import app.gamenative.utils.downloader.GraphicsDriverDownloader
import app.gamenative.utils.BrightnessManager
import app.gamenative.utils.downloader.WinComponentDownloader
import app.gamenative.utils.WineProcessSnapshotHelper
import com.winlator.alsaserver.ALSAClient
import com.winlator.container.Container
import com.winlator.container.ContainerFiles
import com.winlator.container.ContainerManager
import com.winlator.container.ContainerOverlayMigrator
import com.winlator.contents.AdrenotoolsManager
import com.winlator.contents.ContentProfile
import com.winlator.contents.ContentsManager
import com.winlator.core.AppUtils
import com.winlator.core.Callback
import com.winlator.core.DXVKHelper
import com.winlator.core.DefaultVersion
import com.winlator.core.FileUtils
import com.winlator.core.GPUHelper
import com.winlator.core.GPUInformation
import com.winlator.core.KeyValueSet
import com.winlator.core.OnExtractFileListener
import com.winlator.core.ProcessHelper
import com.winlator.core.SharedComponents
import com.winlator.core.TarCompressorUtils
import com.winlator.core.Win32AppWorkarounds
import com.winlator.core.WineInfo
import com.winlator.core.WineRegistryEditor
import com.winlator.core.WineThemeManager
import com.winlator.core.WineUtils
import com.winlator.core.envvars.EnvVarRedaction
import com.winlator.core.envvars.EnvVars
import com.winlator.fexcore.FEXCoreManager
import com.winlator.fexcore.FEXCorePreset
import com.winlator.inputcontrols.ControllerManager
import com.winlator.inputcontrols.ControlsProfile
import com.winlator.inputcontrols.ExternalController
import com.winlator.inputcontrols.InputControlsManager
import com.winlator.inputcontrols.TouchMouse
import com.winlator.widget.FrameRating
import com.winlator.widget.InputControlsView
import com.winlator.widget.TouchpadView
import com.winlator.renderer.ASurfaceRenderer
import com.winlator.renderer.GLRenderer
import com.winlator.renderer.VulkanRenderer
import com.winlator.widget.XServerRendererView
import com.winlator.widget.XServerView
import com.winlator.widget.XServerViewGL
import com.winlator.winhandler.WinHandler
import com.winlator.winhandler.WinHandler.PreferredInputApi
import com.winlator.winhandler.OnGetProcessInfoListener
import com.winlator.winhandler.ProcessInfo
import com.winlator.xconnector.UnixSocketConfig
import com.winlator.xenvironment.ImageFs
import com.winlator.xenvironment.XEnvironment
import com.winlator.xenvironment.components.ALSAServerComponent
import com.winlator.xenvironment.components.BionicProgramLauncherComponent
import com.winlator.xenvironment.components.GlibcProgramLauncherComponent
import com.winlator.xenvironment.components.GuestProgramLauncherComponent
import com.winlator.xenvironment.components.NetworkInfoUpdateComponent
import com.winlator.xenvironment.components.MicrophoneComponent
import com.winlator.xenvironment.components.PulseAudioComponent
import com.winlator.xenvironment.components.SysVSharedMemoryComponent
import com.winlator.xenvironment.components.VirGLRendererComponent
import com.winlator.xenvironment.components.VortekRendererComponent
import com.winlator.xenvironment.components.XServerComponent
import com.winlator.xserver.Keyboard
import com.winlator.xserver.Property
import com.winlator.xserver.ScreenInfo
import com.winlator.xserver.ShmFramePacer
import com.winlator.xserver.Window
import com.winlator.xserver.WindowManager
import com.winlator.xserver.XServer
import com.winlator.xserver.extensions.PresentExtension
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONException
import org.json.JSONObject
import timber.log.Timber
import java.io.File
import java.io.IOException
import java.nio.file.Files
import java.nio.file.Paths
import java.nio.file.StandardCopyOption
import java.nio.file.StandardCopyOption.REPLACE_EXISTING
import java.util.Arrays
import java.util.Locale
import kotlin.math.ceil
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread
import kotlin.io.path.name
import kotlin.math.roundToInt
import kotlin.text.lowercase
import com.winlator.PrefManager as WinlatorPrefManager

private const val ALWAYS_REEXTRACT = false
private val isExiting = AtomicBoolean(false)
private const val EXIT_PROCESS_TIMEOUT_MS = 30_000L
private const val EXIT_PROCESS_POLL_INTERVAL_MS = 1_000L
private const val EXIT_PROCESS_RESPONSE_TIMEOUT_MS = 2_000L
private const val QUICK_MENU_PROCESS_POLL_INTERVAL_MS = 2_000L
private const val DEFAULT_FPS_LIMITER_MAX_HZ = 60
private const val DEFAULT_FPS_LIMITER_TARGET_HZ = 60
private const val FPS_LIMITER_ENABLED_EXTRA = "fpsLimiterEnabled"
private const val FPS_LIMITER_TARGET_EXTRA = "fpsLimiterTarget"

private fun initialFpsLimiterEnabled(container: Container): Boolean =
parseBooleanExtra(container.getExtra(FPS_LIMITER_ENABLED_EXTRA)) ?: true
private fun initialFpsLimiterTarget(container: Container): Int =
parsePositiveFpsLimit(container.getExtra(FPS_LIMITER_TARGET_EXTRA)) ?: DEFAULT_FPS_LIMITER_TARGET_HZ
private fun detectMaxRefreshRateHz(context: Context, attachedView: View?): Int {
val display = attachedView?.display ?: context.display ?: ContextCompat.getSystemService(context, DisplayManager::class.java)?.getDisplay(Display.DEFAULT_DISPLAY)
val refreshRate = when {
display == null -> DEFAULT_FPS_LIMITER_MAX_HZ.toFloat()
Build.VERSION.SDK_INT >= Build.VERSION_CODES.M -> {
val supportedMax = display.supportedModes.maxOfOrNull { it.refreshRate } ?: display.refreshRate
if (supportedMax.isFinite() && supportedMax > 0f) supportedMax else display.refreshRate
}
else -> display.refreshRate
}
return refreshRate.takeIf { it.isFinite() && it > 0f }?.roundToInt()?.coerceAtLeast(5) ?: DEFAULT_FPS_LIMITER_MAX_HZ
}
private data class XServerViewReleaseBinding(
val xServerView: XServerRendererView,
val windowModificationListener: WindowManager.OnWindowModificationListener,
var gameHost: FrameLayout? = null,
var gameHostLayoutListener: OnLayoutChangeListener? = null,
val screenWidth: Int,
)
private data class ControllerSlotUiState(
val slotIndex: Int,
val enabled: Boolean,
val status: String,
val controllerName: String,
val deviceId: String,
val androidInputSource: String,
val guestInputMethod: String,
)
private data class ConnectedControllerUiState(
val name: String,
val deviceId: String,
val slotLabel: String,
val androidInputSource: String,
)
private data class ControllerStatusSnapshot(
val slots: List,
val connectedControllers: List,
val guestApi: String,
)
private val CORE_WINE_PROCESSES = setOf("wineserver", "services", "start", "winhandler", "tabtip", "explorer", "winedevice", "svchost")
private fun normalizeProcessName(name: String): String {
val trimmed = name.trim().trim('"')
val base = trimmed.substringAfterLast('/').substringAfterLast('\')
val lower = base.lowercase(Locale.getDefault())
return if (lower.endsWith(".exe")) lower.removeSuffix(".exe") else lower
}
internal fun parseScreenSize(screenSize: String): Pair<Int, Int>? {
val parts = screenSize.lowercase(Locale.getDefault()).split("x")
if (parts.size != 2) return null
val width = parts[0].trim().toIntOrNull() ?: return null
val height = parts[1].trim().toIntOrNull() ?: return null
if (width <= 0 || height <= 0) return null
return width to height
}
internal fun portraitGameHostHeight(isPortrait: Boolean, screenWidth: Int, availableHeight: Int, screenSize: String): Int {
if (!isPortrait) return ViewGroup.LayoutParams.MATCH_PARENT
val (renderWidth, renderHeight) = parseScreenSize(screenSize) ?: return ViewGroup.LayoutParams.MATCH_PARENT
val aspectHeight = ceil(screenWidth * (renderHeight.toFloat() / renderWidth.toFloat())).toInt()
return if (availableHeight > 0) minOf(aspectHeight, availableHeight) else aspectHeight
}
internal fun portraitCutoutTopInset(belowCutout: Boolean, cutoutTop: Int, hostTopInWindow: Int): Int {
if (!belowCutout) return 0
return (cutoutTop - hostTopInWindow).coerceAtLeast(0)
}
private fun portraitCutoutTopInset(host: View, belowCutout: Boolean): Int {
if (!belowCutout) return 0
val cutoutTop = ViewCompat.getRootWindowInsets(host)?.getInsets(WindowInsetsCompat.Type.displayCutout())?.top ?: return 0
val location = IntArray(2)
host.getLocationInWindow(location)
return portraitCutoutTopInset(belowCutout, cutoutTop, location[1])
}
private fun updatePortraitGameHostHeight(gameHost: View, isPortrait: Boolean, belowCutout: Boolean, screenWidth: Int, screenSize: String) {
val params = gameHost.layoutParams ?: return
val host = gameHost.parent as? View
val topInset = if (isPortrait && host != null) portraitCutoutTopInset(host, belowCutout) else 0
if (host != null && host.paddingTop != topInset) {
host.setPadding(host.paddingLeft, topInset, host.paddingRight, host.paddingBottom)
}
val height = portraitGameHostHeight(isPortrait, screenWidth, ((host?.height ?: 0) - topInset).coerceAtLeast(0), screenSize)
if (params.height != height) {
params.height = height
gameHost.layoutParams = params
}
}
private fun extractExecutableBasename(path: String): String {
if (path.isBlank()) return ""
return normalizeProcessName(path)
}
private fun windowMatchesExecutable(window: Window, targetExecutable: String): Boolean {
if (targetExecutable.isBlank()) return false
val normalizedTarget = normalizeProcessName(targetExecutable)
val candidates = listOf(window.name, window.className)
return candidates.any { candidate ->
candidate.split('\u0000').asSequence().map { normalizeProcessName(it) }.any { it == normalizedTarget }
}
}
private fun buildEssentialProcessAllowlist(): Set {
val essentialServices = WineUtils.getEssentialServiceNames().map { normalizeProcessName(it) }
return (essentialServices + CORE_WINE_PROCESSES).toSet()
}
@Composable
private fun SyncGyroOverlaySuppression(suppressed: Boolean, viewKey: XServerRendererView?) {
LaunchedEffect(suppressed, viewKey) {
PluviaApp.inputControlsView?.setGyroOverlaySuppressed(suppressed)
}
}
@Composable
@OptIn(ExperimentalComposeUiApi::class)
fun XServerScreen(
lifecycleOwner: LifecycleOwner = LocalLifecycleOwner.current,
appId: String,
isOffline: Boolean = false,
registerBackAction: ( ( ) -> Unit ) -> Unit,
navigateBack: () -> Unit,
onExit: (onComplete: (() -> Unit)?) -> Unit,
onWindowMapped: ((Context, Window) -> Unit)? = null,
onWindowUnmapped: ((Window) -> Unit)? = null,
onGameLaunchError: ((String) -> Unit)? = null,
) {
Timber.i("Starting up XServerScreen")
val context = LocalContext.current
val view = LocalView.current
val scope = rememberCoroutineScope()
val imm = remember(context) { context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager }
var firstTimeBoot = false
var needsUnpacking = false
var containerVariantChanged = false
var frameRating by remember { mutableStateOf<FrameRating?>(null) }
var frameRatingWindowId = -1
var vkbasaltConfig = ""
var taskAffinityMask = 0
var taskAffinityMaskWoW64 = 0
DisposableEffect(Unit) {
isExiting.set(false)
onDispose { isExiting.set(false) }
}
val container = remember(appId) { ContainerUtils.getContainer(context, appId) }
val activity = remember(context) { BrightnessManager.findActivity(context) }
DisposableEffect(activity) {
onDispose { if (activity != null) BrightnessManager.clearDisplayBrightnessOverride(activity) }
}
val suspendPolicy = remember(container.id) { container.suspendPolicy }
val neverSuspend = suspendPolicy.equals(Container.SUSPEND_POLICY_NEVER, ignoreCase = true)
val manualResumeMode = suspendPolicy.equals(Container.SUSPEND_POLICY_MANUAL, ignoreCase = true)
SideEffect { PluviaApp.setActiveSuspendPolicy(suspendPolicy) }
PluviaApp.events.emit(AndroidEvent.SetAllowedOrientation(if (container.isPortraitMode) EnumSet.of(Orientation.PORTRAIT) else PrefManager.allowedOrientation))
val xServerState = rememberSaveable(stateSaver = XServerState.Saver) {
mutableStateOf(XServerState(graphicsDriver = container.graphicsDriver, graphicsDriverVersion = container.graphicsDriverVersion, audioDriver = container.audioDriver, dxwrapper = container.dxWrapper, dxwrapperConfig = DXVKHelper.parseConfig(container.dxWrapperConfig), screenSize = container.screenSize))
}
var touchMouse by remember {
val result = mutableStateOf<TouchMouse?>(null)
Timber.i("Remembering touchMouse as $result")
result
}
var keyboard by remember { mutableStateOf<Keyboard?>(null) }
val gameId = ContainerUtils.extractGameIdFromContainerId(appId)
var xServerView: XServerRendererView? by remember {
val result = mutableStateOf<XServerRendererView?>(null)
Timber.i("Remembering xServerView as $result")
result
}
var swapInputOverlay: SwapInputOverlayView? by remember { mutableStateOf(null) }
var imeInputReceiver: app.gamenative.externaldisplay.IMEInputReceiver? by remember { mutableStateOf(null) }
var win32AppWorkarounds: Win32AppWorkarounds? by remember { mutableStateOf(null) }
var physicalControllerHandler: PhysicalControllerHandler? by remember { mutableStateOf(null) }
var exitWatchJob: Job? by remember { mutableStateOf(null) }
val keyboardEscMenuHandler = remember(scope) { KeyboardEscMenuHandler(scope) }
DisposableEffect(Unit) {
onDispose {
PluviaApp.radialMenuCoordinator?.detach()
PluviaApp.radialMenuCoordinator = null
physicalControllerHandler?.cleanup()
physicalControllerHandler = null
exitWatchJob?.cancel()
exitWatchJob = null
keyboardEscMenuHandler.cancel()
}
}
var isKeyboardVisible = false
var areControlsVisible by remember { mutableStateOf(false) }
var isDisableMouseInput by remember(container.id) { mutableStateOf(container.isDisableMouseInput) }
var isEditMode by remember { mutableStateOf(false) }
var gameRoot by remember { mutableStateOf<View?>(null) }
var windowModificationListener by remember { mutableStateOf<WindowManager.OnWindowModificationListener?>(null) }
var elementPositionsSnapshot by remember { mutableStateOf<Map<com.winlator.inputcontrols.ControlElement, Pair<Int, Int>>>(emptyMap()) }
var showElementEditor by remember { mutableStateOf(false) }
var elementToEdit by remember { mutableStateOf<com.winlator.inputcontrols.ControlElement?>(null) }
var showPhysicalControllerDialog by remember { mutableStateOf(false) }
var showTouchGestureDialog by remember { mutableStateOf(false) }
var showShooterModeDialog by remember(container.id) { mutableStateOf(false) }
var isTouchscreenModeActive by remember { mutableStateOf(container.isTouchscreenMode) }
var isShooterModeActive by remember(container.id) { mutableStateOf(container.isShooterMode) }
var currentGestureConfig by remember { mutableStateOf(app.gamenative.data.TouchGestureConfig.fromJson(container.getGestureConfig())) }
var currentShooterConfig by remember(container.id) { mutableStateOf(ShooterModeConfig.fromJson(container.getShooterConfig())) }
fun shouldShowMouseCursor(): Boolean {
return !container.isDisableMouseInput && (!container.isTouchscreenMode || currentGestureConfig.showCursorInTouchscreenMode)
}
fun applyMouseCursorVisibility() {
xServerView?.renderer?.setCursorVisible(shouldShowMouseCursor())
}
val clickHighlightPoints = remember { mutableStateListOf<app.gamenative.ui.component.HighlightPoint>() }
var debugGestureName by remember { mutableStateOf("") }
var debugGestureKey by remember { mutableIntStateOf(0) }
var keyboardRequestedFromOverlay by remember { mutableStateOf(false) }
var shouldForceResumeOnMenuClose by remember { mutableStateOf(false) }
var showQuickMenu by remember { mutableStateOf(false) }
var quickMenuToolsVisible by remember { mutableStateOf(false) }
var quickMenuWineProcesses by remember { mutableStateOf<List>(emptyList()) }
var quickMenuWineProcessesLoading by remember { mutableStateOf(false) }
var hasPhysicalController by remember { mutableStateOf(false) }
var controllerSlotStatusVersion by remember { mutableIntStateOf(0) }
var keepPausedForEditor by remember { mutableStateOf(false) }
var hasPhysicalKeyboard by remember { mutableStateOf(false) }
var hasPhysicalMouse by remember { mutableStateOf(false) }
var usingScreenMirror by remember { mutableStateOf(false) }
var hasInternalTouchpad by remember { mutableStateOf(false) }
var hasUpdatedScreenGamepad by remember { mutableStateOf(false) }
var isPerformanceHudEnabled by remember { mutableStateOf(PrefManager.showFps) }
val shouldTrackDisplayedFrames = remember { AtomicBoolean(false) }
var detectedMaxRefreshRateHz by remember { mutableIntStateOf(detectMaxRefreshRateHz(context, null)) }
var fpsLimiterEnabled by rememberSaveable(container.id) { mutableStateOf(initialFpsLimiterEnabled(container)) }
var fpsLimiterTarget by rememberSaveable(container.id) { mutableIntStateOf(initialFpsLimiterTarget(container)) }
val gyroOverlaySuppressed = showQuickMenu || keepPausedForEditor || showElementEditor || showPhysicalControllerDialog || showTouchGestureDialog || showShooterModeDialog || isEditMode
SyncGyroOverlaySuppression(suppressed = gyroOverlaySuppressed, viewKey = xServerView)
val isLsfgAvailable = LsfgQuickMenuHelper.isAvailable(container)
val initialLsfgSettings = remember(container.id) { LsfgQuickMenuHelper.readSettings(container) }
var lsfgMultiplier by rememberSaveable(container.id) { mutableIntStateOf(initialLsfgSettings.multiplier) }
var lsfgFlowScale by rememberSaveable(container.id) { mutableStateOf(initialLsfgSettings.flowScale) }
var lsfgPerformanceMode by rememberSaveable(container.id) { mutableStateOf(initialLsfgSettings.performanceMode) }
fun persistFpsLimiterState() {
container.putExtra(FPS_LIMITER_ENABLED_EXTRA, fpsLimiterEnabled)
container.putExtra(FPS_LIMITER_TARGET_EXTRA, fpsLimiterTarget)
container.saveData()
}
fun loadPerformanceHudConfig(): PerformanceHudConfig {
return PerformanceHudConfig(
showFrameRate = PrefManager.performanceHudShowFrameRate, showCpuUsage = PrefManager.performanceHudShowCpuUsage, showGpuUsage = PrefManager.performanceHudShowGpuUsage, showRamUsage = PrefManager.performanceHudShowRamUsage, showBatteryLevel = PrefManager.performanceHudShowBatteryLevel, showPowerDraw = PrefManager.performanceHudShowPowerDraw, showBatteryRuntime = PrefManager.performanceHudShowBatteryRuntime, showBatteryTemperature = PrefManager.performanceHudShowBatteryTemperature, showClockTime = PrefManager.performanceHudShowClockTime, showCpuTemperature = PrefManager.performanceHudShowCpuTemperature, showGpuTemperature = PrefManager.performanceHudShowGpuTemperature, showFrameRateGraph = PrefManager.performanceHudShowFrameRateGraph, showCpuUsageGraph = PrefManager.performanceHudShowCpuUsageGraph, showGpuUsageGraph = PrefManager.performanceHudShowGpuUsageGraph, backgroundOpacity = PrefManager.performanceHudBackgroundOpacity, colorIntensity = PrefManager.performanceHudColorIntensity, showTextOutline = PrefManager.performanceHudShowTextOutline, size = PerformanceHudSize.fromPrefValue(PrefManager.performanceHudSize)
)
}
var performanceHudConfig by remember { mutableStateOf(loadPerformanceHudConfig()) }
var performanceHudView by remember { mutableStateOf<PerformanceHudView?>(null) }
var performanceHudHost by remember { mutableStateOf<FrameLayout?>(null) }
var isDraggingPerformanceHud by remember { mutableStateOf(false) }
var isTrackingPerformanceHudTouch by remember { mutableStateOf(false) }
var performanceHudTouchDownRawX by remember { mutableStateOf(0f) }
var performanceHudTouchDownRawY by remember { mutableStateOf(0f) }
var performanceHudDragOffsetX by remember { mutableStateOf(0f) }
var performanceHudDragOffsetY by remember { mutableStateOf(0f) }
val performanceHudTouchSlop = ViewConfiguration.get(context).scaledTouchSlop.toFloat()
LaunchedEffect(xServerView?.renderer) {
val screenEffectsConfig = loadScreenEffectsConfig(container)
when (val renderer = xServerView?.renderer) {
is VulkanRenderer -> {
applyScreenEffectsConfig(renderer, screenEffectsConfig)
if (isLsfgAvailable) LsfgVkManager.applyNativeRuntime(renderer, container, context)
}
is GLRenderer -> applyScreenEffectsConfig(renderer, screenEffectsConfig)
}
}
fun applyFpsLimiterToEngines(limit: Int) {
xServerView?.setFrameRateLimit(if (isLsfgAvailable && lsfgMultiplier >= 2) 0 else limit)
xServerView?.getxServer()?.getExtension(PresentExtension.MAJOR_OPCODE.toInt())?.setFrameRateLimit(if (isLsfgAvailable && lsfgMultiplier >= 2) 0 else limit)
ShmFramePacer.setFrameRateLimit(limit)
}
fun effectiveFpsLimit(): Int = if (fpsLimiterEnabled) fpsLimiterTarget else 0
fun applyLsfgSettings() {
LsfgQuickMenuHelper.applySettings(container, LsfgQuickMenuHelper.Settings(lsfgMultiplier, lsfgFlowScale, lsfgPerformanceMode))
}
fun applyFpsLimiterEnabled(enabled: Boolean) {
fpsLimiterEnabled = enabled
applyFpsLimiterToEngines(effectiveFpsLimit())
persistFpsLimiterState()
if (isLsfgAvailable && lsfgMultiplier >= 2) applyLsfgSettings()
}
fun applyFpsLimiterTarget(target: Int) {
val sanitized = target.coerceAtLeast(5).coerceAtMost(detectedMaxRefreshRateHz)
fpsLimiterTarget = sanitized
if (fpsLimiterEnabled) applyFpsLimiterToEngines(effectiveFpsLimit())
persistFpsLimiterState()
if (isLsfgAvailable && lsfgMultiplier >= 2) applyLsfgSettings()
}
fun applyLsfgMultiplier(mult: Int) {
lsfgMultiplier = LsfgQuickMenuHelper.sanitizeMultiplier(mult)
applyLsfgSettings()
applyFpsLimiterToEngines(effectiveFpsLimit())
}
fun applyLsfgFlowScale(scale: Float) {
lsfgFlowScale = LsfgQuickMenuHelper.sanitizeFlowScale(scale)
applyLsfgSettings()
}
fun applyLsfgPerformanceMode(enabled: Boolean) {
lsfgPerformanceMode = enabled
applyLsfgSettings()
}
LaunchedEffect(xServerView) {
val detectedMax = detectMaxRefreshRateHz(context, xServerView as? View)
detectedMaxRefreshRateHz = detectedMax
val clampedTarget = fpsLimiterTarget.coerceAtMost(detectedMax).coerceAtLeast(5)
if (clampedTarget != fpsLimiterTarget) fpsLimiterTarget = clampedTarget
applyFpsLimiterToEngines(effectiveFpsLimit())
}
fun restorePerformanceHudPosition() {
val host = performanceHudHost ?: return
val hud = performanceHudView ?: return
if (host.width <= 0 || host.height <= 0 || hud.width <= 0 || hud.height <= 0) return
val maxX = (host.width - hud.width).coerceAtLeast(0).toFloat()
val maxY = (host.height - hud.height).coerceAtLeast(0).toFloat()
val margin = 12 * context.resources.displayMetrics.density
val savedX = PrefManager.performanceHudXFraction
val savedY = PrefManager.performanceHudYFraction
hud.x = if (savedX in 0f..1f) maxX * savedX else margin.coerceAtMost(maxX)
hud.y = if (savedY in 0f..1f) maxY * savedY else margin.coerceAtMost(maxY)
PrefManager.performanceHudXFraction = if (maxX > 0f) hud.x / maxX else 0f
PrefManager.performanceHudYFraction = if (maxY > 0f) hud.y / maxY else 0f
}
fun movePerformanceHud(rawX: Float, rawY: Float, save: Boolean) {
val host = performanceHudHost ?: return
val hud = performanceHudView ?: return
if (host.width <= 0 || host.height <= 0 || hud.width <= 0 || hud.height <= 0) return
val hostLocation = IntArray(2)
host.getLocationOnScreen(hostLocation)
val maxX = (host.width - hud.width).coerceAtLeast(0).toFloat()
val maxY = (host.height - hud.height).coerceAtLeast(0).toFloat()
hud.x = (rawX - hostLocation[0] - performanceHudDragOffsetX).coerceIn(0f, maxX)
hud.y = (rawY - hostLocation[1] - performanceHudDragOffsetY).coerceIn(0f, maxY)
if (save) {
PrefManager.performanceHudXFraction = if (maxX > 0f) hud.x / maxX else 0f
PrefManager.performanceHudYFraction = if (maxY > 0f) hud.y / maxY else 0f
}
}
fun removePerformanceHud() {
isDraggingPerformanceHud = false
isTrackingPerformanceHudTouch = false
performanceHudView?.let { hud -> (hud.parent as? ViewGroup)?.removeView(hud) }
performanceHudView = null
}
fun togglePerformanceHudLayout() {
val hud = performanceHudView ?: return
val compactMode = !hud.isCompactMode()
hud.setCompactMode(compactMode)
PrefManager.performanceHudCompactMode = compactMode
hud.post { if (performanceHudView === hud && !isDraggingPerformanceHud) restorePerformanceHudPosition() }
}
fun updatePerformanceHud(show: Boolean) {
if (!show) { removePerformanceHud(); return }
if (performanceHudView != null) return
val targetLayout = performanceHudHost ?: return
val hud = PerformanceHudView(context = context, fpsProvider = {
val raw = frameRating?.currentFPS ?: 0f
if (isLsfgAvailable && lsfgMultiplier >= 2) LsfgVkManager.readMeasuredFps(container) ?: raw else raw
}, initialConfig = performanceHudConfig, initialCompactMode = PrefManager.performanceHudCompactMode)
val layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { gravity = Gravity.TOP or Gravity.START }
targetLayout.addView(hud, layoutParams)
performanceHudView = hud
hud.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> if (!isDraggingPerformanceHud) restorePerformanceHudPosition() }
targetLayout.post { if (performanceHudView === hud) restorePerformanceHudPosition() }
hud.bringToFront()
}
fun clearOverlayPauseState() {
PluviaApp.isOverlayPaused = false
PluviaApp.inputControlsView?.setGyroGameplayActive(true)
}
fun pauseForOverlayIfAllowed() {
if (neverSuspend) return
PluviaApp.xEnvironment?.onPause()
PluviaApp.isOverlayPaused = true
PluviaApp.inputControlsView?.setGyroGameplayActive(false)
}
fun resumeIfAllowedAfterOverlay() {
if (!PluviaApp.isOverlayPaused) return
if (neverSuspend) { clearOverlayPauseState(); return }
if (manualResumeMode) return
PluviaApp.xEnvironment?.onResume()
clearOverlayPauseState()
}
fun forceResumeIfSuspended() {
if (PluviaApp.isOverlayPaused && !neverSuspend) PluviaApp.xEnvironment?.onResume()
clearOverlayPauseState()
}
fun resumeFromManualButton() {
if (!PluviaApp.isOverlayPaused) return
if (!neverSuspend) PluviaApp.xEnvironment?.onResume()
keepPausedForEditor = false
clearOverlayPauseState()
}
fun startExitWatchForUnmappedGameWindow(window: Window) {
val winHandler = xServerView?.getxServer()?.winHandler ?: return
if (exitWatchJob?.isActive == true) return
val targetExecutable = extractExecutableBasename(container.executablePath)
if (!windowMatchesExecutable(window, targetExecutable)) return
exitWatchJob = CoroutineScope(Dispatchers.IO).launch {
val allowlist = buildEssentialProcessAllowlist()
val previousListener = winHandler.getOnGetProcessInfoListener()
val lock = Any()
var pendingSnapshot: CompletableDeferred<List?>? = null
var currentList = mutableListOf()
var expectedCount = 0
val listener = OnGetProcessInfoListener { index, count, processInfo ->
previousListener?.onGetProcessInfo(index, count, processInfo)
synchronized(lock) {
val deferred = pendingSnapshot ?: return@synchronized
if (count == 0 && processInfo == null) {
if (!deferred.isCompleted) deferred.complete(null)
return@synchronized
}
if (index == 0) { currentList = mutableListOf(); expectedCount = count }
if (processInfo != null) currentList.add(processInfo)
if (currentList.size >= expectedCount && !deferred.isCompleted) deferred.complete(currentList.toList())
}
}
winHandler.setOnGetProcessInfoListener(listener)
try {
val startTime = System.currentTimeMillis()
while (System.currentTimeMillis() - startTime < EXIT_PROCESS_TIMEOUT_MS) {
val deferred = CompletableDeferred<List?>()
synchronized(lock) { pendingSnapshot = deferred }
winHandler.listProcesses()
val snapshot = withTimeoutOrNull(EXIT_PROCESS_RESPONSE_TIMEOUT_MS) { deferred.await() }
if (snapshot != null) {
val hasNonEssential = snapshot.any { !allowlist.contains(normalizeProcessName(it.name)) }
if (!hasNonEssential) {
withContext(Dispatchers.Main) { exit(winHandler, frameRating, container, appId, onExit, navigateBack, "processes_exited") }
break
}
}
delay(EXIT_PROCESS_POLL_INTERVAL_MS)
}
} finally {
winHandler.setOnGetProcessInfoListener(previousListener)
synchronized(lock) { pendingSnapshot = null }
}
}
}
val tryCapturePointer: () -> Boolean = {
if (!showElementEditor && !keepPausedForEditor && !showQuickMenu && !isEditMode && !container.isTouchscreenMode) {
PluviaApp.touchpadView?.postDelayed({
val view = PluviaApp.touchpadView
if (view != null) { view.requestFocus(); view.requestPointerCapture() }
}, 100)
true
} else false
}
fun scanForExternalDevices() {
val deviceIds = InputDevice.getDeviceIds()
hasPhysicalKeyboard = deviceIds.any { id ->
val device = InputDevice.getDevice(id) ?: return@any false
val isExternal = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) device.isExternal else true
Keyboard.isKeyboardDevice(device) && !device.isVirtual && isExternal
}
hasPhysicalMouse = deviceIds.any { id ->
val device = InputDevice.getDevice(id) ?: return@any false
val isMouse = device.supportsSource(InputDevice.SOURCE_MOUSE) || device.supportsSource(InputDevice.SOURCE_MOUSE_RELATIVE) || device.supportsSource(InputDevice.SOURCE_TOUCHPAD)
val isExternal = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) device.isExternal else true
isMouse && !device.isVirtual && isExternal
}
val controllerManager = ControllerManager.getInstance()
controllerManager.autoAssignConnectedDevices()
hasPhysicalController = controllerManager.getDetectedDevices().isNotEmpty()
controllerSlotStatusVersion++
xServerView?.getxServer()?.winHandler?.refreshControllerMappingsForHotplug()
if (!usingScreenMirror && !hasInternalTouchpad && !hasPhysicalMouse && !hasPhysicalKeyboard && !hasPhysicalController && !container.isTouchscreenMode) {
val manager = PluviaApp.inputControlsManager
val profiles = manager?.getProfiles(false) ?: listOf()
if (profiles.isNotEmpty()) {
val profileIdStr = container.getExtra("profileId", "0")
val profileId = profileIdStr.toIntOrNull() ?: 0
val targetProfile = if (profileId != 0) manager?.getProfile(profileId) else null ?: manager?.getProfile(0) ?: profiles.getOrNull(2) ?: profiles.first()
if (!showElementEditor && !keepPausedForEditor && !showQuickMenu && !isEditMode) {
if (!areControlsVisible) { showInputControls(targetProfile, xServerView!!.getxServer().winHandler, container); areControlsVisible = true }
PluviaApp.touchpadView?.postDelayed({ PluviaApp.touchpadView?.releasePointerCapture() }, 100)
}
hasUpdatedScreenGamepad = false
}
}
}
fun evaluateDevice(device: InputDevice) {
val isExternal = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) device.isExternal else true
if (!device.isVirtual && isExternal) {
if (Keyboard.isKeyboardDevice(device)) {
hasPhysicalKeyboard = true
if (!showElementEditor && !keepPausedForEditor && !showQuickMenu && !isEditMode && !container.isTouchscreenMode && !hasUpdatedScreenGamepad) {
hasUpdatedScreenGamepad = true; hideInputControls(); areControlsVisible = false
}
}
val isMouse = device.supportsSource(InputDevice.SOURCE_MOUSE) || device.supportsSource(InputDevice.SOURCE_MOUSE_RELATIVE) || device.supportsSource(InputDevice.SOURCE_TOUCHPAD)
if (isMouse) {
hasPhysicalMouse = true
if (!hasUpdatedScreenGamepad && tryCapturePointer()) { hasUpdatedScreenGamepad = true; hideInputControls(); areControlsVisible = false }
}
}
val isGamepad = ExternalController.isGameController(device)
if (isGamepad) {
ControllerManager.getInstance().onDeviceConnected(device.id)
controllerSlotStatusVersion++
xServerView?.getxServer()?.winHandler?.setCurrentController(device.id)
xServerView?.getxServer()?.winHandler?.refreshControllerMappingsForHotplug()
if (!showElementEditor && !keepPausedForEditor && !showQuickMenu && !isEditMode && !container.isTouchscreenMode && !hasUpdatedScreenGamepad) {
hasUpdatedScreenGamepad = true; hideInputControls(); areControlsVisible = false
}
}
}
val dismissOverlayMenu: () -> Unit = {
if (!keyboardRequestedFromOverlay) imeInputReceiver?.hideKeyboard()
shouldForceResumeOnMenuClose = keyboardRequestedFromOverlay && manualResumeMode && !keepPausedForEditor
keyboardRequestedFromOverlay = false
showQuickMenu = false
}
val showSoftKeyboard: (View, String) -> Unit = { anchor, _ ->
anchor.post {
if (anchor.windowToken != null) {
val show = { imeInputReceiver?.showKeyboard() ?: imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0) }
if (Build.VERSION.SDK_INT > 29) anchor.postDelayed({ show() }, 500) else show()
}
}
}
val onQuickMenuItemSelected: (Int) -> Boolean = { itemId ->
when (itemId) {
QuickMenuAction.KEYBOARD -> { keyboardRequestedFromOverlay = true; showSoftKeyboard(view, "onscreen_keyboard_enabled"); true }
QuickMenuAction.INPUT_CONTROLS -> {
if (areControlsVisible) hideInputControls() else {
val manager = PluviaApp.inputControlsManager
val profiles = manager?.getProfiles(false) ?: listOf()
if (profiles.isNotEmpty()) {
val profileIdStr = container.getExtra("profileId", "0")
val profileId = profileIdStr.toIntOrNull() ?: 0
val targetProfile = if (profileId != 0) manager?.getProfile(profileId) else null ?: manager?.getProfile(0) ?: profiles.getOrNull(2) ?: profiles.first()
showInputControls(targetProfile, xServerView!!.getxServer().winHandler, container)
}
}
areControlsVisible = !areControlsVisible; true
}
QuickMenuAction.DISABLE_MOUSE -> {
val newValue = !isDisableMouseInput; isDisableMouseInput = newValue
container.setDisableMouseInput(newValue); container.saveData()
PluviaApp.touchpadView?.setTouchscreenMouseDisabled(newValue)
if (newValue) xServerView?.renderer?.setCursorVisible(false) else applyMouseCursorVisibility()
true
}
QuickMenuAction.EDIT_CONTROLS -> {
keepPausedForEditor = true
val manager = PluviaApp.inputControlsManager ?: InputControlsManager(context)
val allProfiles = manager.getProfiles(false)
val profileIdStr = container.getExtra("profileId", "0")
val profileId = profileIdStr.toIntOrNull() ?: 0
var activeProfile = if (profileId != 0) manager.getProfile(profileId) else null
if (activeProfile == null) {
val sourceProfile = manager.getProfile(0) ?: allProfiles.firstOrNull { it.id == 2 } ?: allProfiles.firstOrNull()
if (sourceProfile != null) {
try {
activeProfile = manager.duplicateProfile(sourceProfile)
activeProfile.setName("${container.name} - Controls"); activeProfile.save()
container.putExtra("profileId", activeProfile.id.toString()); container.saveData()
PluviaApp.inputControlsView?.setProfile(activeProfile)
PluviaApp.radialMenuCoordinator?.setProfile(activeProfile)
physicalControllerHandler?.setProfile(activeProfile)
} catch (e: Exception) { Timber.e(e, "Failed to auto-create profile"); activeProfile = sourceProfile }
}
}
if (activeProfile != null) {
val profile = PluviaApp.inputControlsView?.profile
if (profile != null) {
val snapshot = mutableMapOf<com.winlator.inputcontrols.ControlElement, Pair<Int, Int>>()
profile.elements.forEach { snapshot[it] = Pair(it.x.toInt(), it.y.toInt()) }
elementPositionsSnapshot = snapshot
}
isEditMode = true; PluviaApp.inputControlsView?.setEditMode(true)
PluviaApp.inputControlsView?.let { icView -> icView.post { activeProfile.loadElements(icView) } }
if (!areControlsVisible) { showInputControls(activeProfile, xServerView!!.getxServer().winHandler, container); areControlsVisible = true }
}
true
}
QuickMenuAction.TOUCHSCREEN_MODE -> {
val newMode = !container.isTouchscreenMode; container.setTouchscreenMode(newMode); container.saveData()
isTouchscreenModeActive = newMode; PluviaApp.touchpadView?.setTouchscreenMode(newMode)
if (newMode) {
PluviaApp.touchpadView?.setGestureConfig(currentGestureConfig)
if (areControlsVisible) { hideInputControls(); areControlsVisible = false }
}
applyMouseCursorVisibility(); false
}
QuickMenuAction.SHOOTER_MODE -> {
val newMode = !container.isShooterMode; container.setShooterMode(newMode); container.saveData()
isShooterModeActive = newMode
if (newMode && !areControlsVisible) {
val manager = PluviaApp.inputControlsManager
val profiles = manager?.getProfiles(false) ?: listOf()
val winHandler = xServerView?.getxServer()?.winHandler
if (profiles.isNotEmpty() && winHandler != null) {
val profileId = container.getExtra("profileId", "0").toIntOrNull() ?: 0
val targetProfile = if (profileId != 0) manager?.getProfile(profileId) else null ?: manager?.getProfile(0) ?: profiles.getOrNull(2) ?: profiles.first()
showInputControls(targetProfile, winHandler, container); areControlsVisible = true
}
}
PluviaApp.inputControlsView?.setContainerShooterMode(newMode)
PluviaApp.inputControlsView?.setShooterModeConfig(currentShooterConfig); false
}
QuickMenuAction.EDIT_PHYSICAL_CONTROLLER -> { keepPausedForEditor = true; showPhysicalControllerDialog = true; true }
QuickMenuAction.RADIAL_MENU -> PluviaApp.radialMenuCoordinator?.showSettingsDialog() == true
QuickMenuAction.PERFORMANCE_HUD -> { val enabled = !isPerformanceHudEnabled; isPerformanceHudEnabled = enabled; PrefManager.showFps = enabled; updatePerformanceHud(enabled); false }
QuickMenuAction.EXIT_GAME -> {
imeInputReceiver?.hideKeyboard()
if (PluviaApp.isOverlayPaused && !neverSuspend) PluviaApp.xEnvironment?.resumeGameProcesses()
clearOverlayPauseState()
exit(xServerView!!.getxServer().winHandler, frameRating, container, appId, onExit, navigateBack, "quick_menu"); true
}
else -> false
}
}
val gameBack: () -> Unit = gameBack@{
val imeVisible = ViewCompat.getRootWindowInsets(view)?.isVisible(WindowInsetsCompat.Type.ime()) == true
if (imeVisible) {
imeInputReceiver?.hideKeyboard()
view.post {
if (Build.VERSION.SDK_INT >= 30) view.windowInsetsController?.hide(WindowInsets.Type.ime())
else { val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager; if (view.windowToken != null) imm.hideSoftInputFromWindow(view.windowToken, 0) }
}
return@gameBack
}
if (showQuickMenu) { dismissOverlayMenu(); return@gameBack }
Timber.i("BackHandler")
ControllerManager.getInstance().scanForDevices()
hasPhysicalController = ControllerManager.getInstance().getDetectedDevices().isNotEmpty()
PluviaApp.touchpadView?.postDelayed({ PluviaApp.touchpadView?.releasePointerCapture() }, 100)
showQuickMenu = true
}
BackHandler(enabled = BuildConfig.MODERN_ANDROID) { gameBack() }
DisposableEffect(container) {
registerBackAction(gameBack)
if (isLsfgAvailable) LsfgVkManager.startVsyncClock(context, container)
onDispose {
Timber.d("XServerScreen leaving, clearing back action")
LsfgVkManager.stopVsyncClock(); removePerformanceHud(); performanceHudHost = null
imeInputReceiver?.hideKeyboard(); imeInputReceiver = null
if (!PluviaApp.keepAlive) PluviaApp.clearActiveSuspendState() else if (!manualResumeMode) PluviaApp.isOverlayPaused = false
registerBackAction { }
}
}
val onActivityDestroyed: (AndroidEvent.ActivityDestroyed) -> Unit = {
Timber.i("onActivityDestroyed")
exit(xServerView!!.getxServer().winHandler, frameRating, container, appId, onExit, navigateBack, "activity_destroyed")
}
val onKeyEvent: (AndroidEvent.KeyEvent) -> Boolean = {
val isKeyboard = Keyboard.isKeyboardDevice(it.event.device)
val isPhysicalKeyboard = isKeyboard && it.event.device?.isVirtual != true
val isGamepad = ExternalController.isGameController(it.event.device)
val waitingForManualResume = manualResumeMode && PluviaApp.isOverlayPaused && !showQuickMenu && !keepPausedForEditor
if (waitingForManualResume) {
when (it.event.keyCode) {
KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_START -> {
if (it.event.action == KeyEvent.ACTION_DOWN && it.event.repeatCount == 0) resumeFromManualButton()
true
}
else -> false
}
} else if ((showElementEditor || keepPausedForEditor || showQuickMenu || isEditMode) && (isGamepad || isKeyboard)) {
if (isKeyboard && it.event.keyCode == KeyEvent.KEYCODE_ESCAPE) {
keyboardEscMenuHandler.handleOverlayEsc(it.event, keyboard)
if (it.event.action == KeyEvent.ACTION_DOWN && it.event.repeatCount == 0) {
if (BuildConfig.MODERN_ANDROID) (context as? ComponentActivity)?.onBackPressedDispatcher?.onBackPressed() else gameBack()
}
true
} else false
} else {
var handled = false
if (isGamepad) {
val winHandler = xServerView!!.getxServer().winHandler
if (it.event.action == KeyEvent.ACTION_DOWN && it.event.repeatCount == 0 && ControllerManager.getInstance().noteGamepadButton(it.event.device.id)) {
winHandler.refreshControllerMappingsForHotplug()
}
val assignedSlot = ControllerManager.getInstance().getSlotForDevice(it.event.device.id)
if (assignedSlot > 0) handled = winHandler.onKeyEvent(it.event)
else {
winHandler.setCurrentController(it.event.device.id)
handled = physicalControllerHandler?.onKeyEvent(it.event) == true
if (!handled) handled = PluviaApp.inputControlsView?.onKeyEvent(it.event) == true
if (!handled) handled = winHandler.onKeyEvent(it.event)
}
}
if (!handled && isKeyboard) {
if (it.event.keyCode == KeyEvent.KEYCODE_ESCAPE && it.event.isShiftPressed && it.event.action == KeyEvent.ACTION_DOWN && it.event.repeatCount == 0) {
keyboardEscMenuHandler.cancel(); gameBack(); handled = true
} else if (isPhysicalKeyboard && keyboardEscMenuHandler.isEsc(it.event) && !showElementEditor && !keepPausedForEditor && !showQuickMenu && !isEditMode) {
handled = keyboardEscMenuHandler.handleGameEsc(event = it.event, keyboard = keyboard, canOpenMenu = { !showElementEditor && !keepPausedForEditor && !showQuickMenu && !isEditMode }, openMenu = gameBack)
} else {
handled = if (it.event.device?.isVirtual == true) keyboard?.onVirtualKeyEvent(it.event) == true else keyboard?.onKeyEvent(it.event) == true
}
}
handled
}
}
val onMotionEvent: (AndroidEvent.MotionEvent) -> Boolean = {
val isGamepad = ExternalController.isGameController(it.event?.device)
if ((showElementEditor || keepPausedForEditor || showQuickMenu || isEditMode) && isGamepad) false
else {
var handled = false
if (isGamepad && it.event != null) {
val winHandler = xServerView!!.getxServer().winHandler
ControllerManager.getInstance().noteGamepadActivity(it.event)
val assignedSlot = ControllerManager.getInstance().getSlotForDevice(it.event.device.id)
if (assignedSlot > 0) handled = winHandler.onGenericMotionEvent(it.event)
else {
winHandler.setCurrentController(it.event.device.id)
handled = physicalControllerHandler?.onGenericMotionEvent(it.event!!) == true
if (!handled) handled = PluviaApp.inputControlsView?.onGenericMotionEvent(it.event) == true
if (!handled) handled = winHandler.onGenericMotionEvent(it.event)
}
}
if (PluviaApp.touchpadView?.hasPointerCapture() != true && !PluviaApp.isOverlayPaused) {
if (it.event?.device != null) {
val device = it.event.device
val isExternal = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) device.isExternal else true
if (device.supportsSource(InputDevice.SOURCE_TOUCHPAD) && !isExternal) {
hasInternalTouchpad = true
if (!showElementEditor && !keepPausedForEditor && !showQuickMenu && !isEditMode && !hasUpdatedScreenGamepad) {
hasUpdatedScreenGamepad = true; hideInputControls(); areControlsVisible = false
}
}
tryCapturePointer()
}
}
if (!usingScreenMirror && it.event?.device?.name == "scrcpy") usingScreenMirror = true
handled
}
}
val onGuestProgramTerminated: (AndroidEvent.GuestProgramTerminated) -> Unit = {
Timber.i("onGuestProgramTerminated")
exit(xServerView!!.getxServer().winHandler, frameRating, container, appId, onExit, navigateBack, "guest_terminated")
}
val onForceCloseApp: (AndroidEvent.ForceCloseApp) -> Unit = {
Timber.i("onForceCloseApp")
exit(xServerView!!.getxServer().winHandler, frameRating, container, appId, onExit, navigateBack, "force_close")
}