package app.gamenative.utils

import android.content.Context
import com.winlator.container.Container
import com.winlator.core.envvars.EnvVars
import com.winlator.renderer.VulkanRenderer
import java.io.File

/**
 * LSFG REMOVED: Implicit layer and async frame generation components disabled for Snapdragon 695.
 * Structure preserved as a stub layer to maintain project UI compatibility.
 */
object LsfgVkManager {
    private const val TAG = "LsfgVkManager"
    private const val LOSSLESS_DLL_NAME = "Lossless.dll"

    private const val CONFIG_RELATIVE_PATH = ".config/lsfg-vk/conf.toml"
    private const val LIB_RELATIVE_DIR = ".local/lib"
    private const val LAYER_RELATIVE_DIR = ".local/share/vulkan/implicit_layer.d"
    private const val DLL_RELATIVE_DIR = ".local/share/lsfg-vk"
    private const val LIB_FILENAME = "liblsfg-vk-layer.so"
    private const val MANIFEST_FILENAME = "VkLayer_LS_frame_generation.json"
    private const val VERSION_FILENAME = ".lsfg_vk_runtime_version"
    private const val MANIFEST_LIBRARY_PATH = "../../../lib/$LIB_FILENAME"
    private const val PROCESS_EXE_IDENTIFIER = "gamenative-lsfg"

    const val EXTRA_ARMED = "lsfgEnabled"
    const val EXTRA_MULTIPLIER = "lsfgMultiplier"
    const val EXTRA_FLOW_SCALE = "lsfgFlowScale"
    const val EXTRA_PERFORMANCE_MODE = "lsfgPerformanceMode"
    const val EXTRA_PRESENT_MODE = "lsfgPresentMode"
    const val EXTRA_BACKEND = "lsfgBackend"

    const val BACKEND_LEGACY = "legacy"
    const val BACKEND_NATIVE = "native"

    private const val EXTRA_FPS_LIMITER_ENABLED = "fpsLimiterEnabled"
    private const val EXTRA_FPS_LIMITER_TARGET = "fpsLimiterTarget"

    private const val STATS_RELATIVE_PATH = ".config/lsfg-vk/stats.txt"
    private const val STATS_FRESHNESS_MS = 2000L

    private const val ENV_DISABLE = "DISABLE_LSFG"
    private const val ENV_CONFIG = "LSFG_CONFIG"
    private const val ENV_PROCESS = "LSFG_PROCESS"

    private const val RUNTIME_VERSION = "v1.3.3-android-arm64-v8a"
    private const val ASSET_DIR = "lsfg_vk/android_arm64_v8a"
    private const val ASSET_MANIFEST = "$ASSET_DIR/$MANIFEST_FILENAME"

    @JvmStatic
    fun isSupported(container: Container): Boolean = false

    @JvmStatic
    fun isArmed(container: Container): Boolean = false

    @JvmStatic
    fun isDllAvailable(): Boolean = false

    @JvmStatic
    fun containerDllPath(container: Container): String? = null

    fun multiplier(container: Container): Int = 0

    fun flowScale(container: Container): Float = 0.80f

    fun performanceMode(container: Container): Boolean = false

    fun presentMode(container: Container): String = "mailbox"

    fun backend(container: Container): String = BACKEND_NATIVE

    @JvmStatic
    fun isNativeBackend(container: Container): Boolean = true

    fun fpsLimit(container: Container): Int = 0

    @JvmStatic
    fun startVsyncClock(context: Context, container: Container) {
        // Disabled for Snapdragon 695
    }

    @JvmStatic
    fun stopVsyncClock() {
        // Disabled for Snapdragon 695
    }

    fun readMeasuredFps(container: Container): Float? = null

    @JvmStatic
    fun prepareNativeCache(context: Context, container: Container): String? = null

    @JvmStatic
    fun applyNativeRuntime(renderer: VulkanRenderer, container: Container, context: Context) {
        // Disabled - Bypasses LSFG pipelines to render directly to Android Swapchain
    }

    fun refreshNativeRuntime(container: Container) {
        // Disabled
    }

    @JvmStatic
    fun ensureRuntimeInstalled(context: Context, container: Container): Boolean = true

    @JvmStatic
    fun writeConfig(container: Container): Boolean = true

    @JvmStatic
    fun applyLaunchEnv(container: Container, envVars: EnvVars): Boolean {
        disableLayerInContainer(container)
        return false
    }

    private fun disableLayerInContainer(container: Container) {
        val layerDir = File(container.rootDir, LAYER_RELATIVE_DIR)
        val manifest = File(layerDir, MANIFEST_FILENAME)
        if (manifest.exists()) {
            manifest.delete()
        }
    }

    private fun writeConfigAtomic(file: File, text: String): Boolean = true

    fun updateConfigAtRuntime(
        container: Container,
        enabled: Boolean,
        multiplier: Int,
        flowScale: Float,
        performanceMode: Boolean,
        fpsLimitOverride: Int? = null
    ): Boolean = false
}
