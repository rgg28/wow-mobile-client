#ifndef _GNU_SOURCE
#define _GNU_SOURCE 1
#endif

#include "lsfg_probe.h"

#include <android/log.h>
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vulkan/vulkan.h>

#if defined(__aarch64__)
#include <adrenotools/driver.h>
#include <sys/stat.h>
#include <unistd.h>

static char* get_native_library_dir(JNIEnv* env, jobject context) {
    if (!env || !context) return NULL;
    jclass cls = (*env)->FindClass(env, "com/winlator/core/AppUtils");
    if (!cls) { (*env)->ExceptionClear(env); return NULL; }
    jmethodID mid = (*env)->GetStaticMethodID(env, cls, "getNativeLibDir",
                                              "(Landroid/content/Context;)Ljava/lang/String;");
    if (!mid) { (*env)->ExceptionClear(env); return NULL; }
    jstring jstr = (jstring)(*env)->CallStaticObjectMethod(env, cls, mid, context);
    if (!jstr) { (*env)->ExceptionClear(env); return NULL; }
    const char* utf = (*env)->GetStringUTFChars(env, jstr, NULL);
    char* res = utf ? strdup(utf) : NULL;
    if (utf) (*env)->ReleaseStringUTFChars(env, jstr, utf);
    return res;
}

static char* get_driver_path(JNIEnv* env, jobject context, const char* driver_name) {
    if (!env || !context || !driver_name) return NULL;
    if (driver_name[0] == '/') {
        return strdup(driver_name);
    }
    jclass contextWrapperClass = (*env)->FindClass(env, "android/content/ContextWrapper");
    if (!contextWrapperClass) { (*env)->ExceptionClear(env); return NULL; }
    jmethodID getFilesDir = (*env)->GetMethodID(env, contextWrapperClass, "getFilesDir", "()Ljava/io/File;");
    if (!getFilesDir) { (*env)->ExceptionClear(env); return NULL; }
    jobject filesDirObj = (*env)->CallObjectMethod(env, context, getFilesDir);
    if (!filesDirObj) { (*env)->ExceptionClear(env); return NULL; }
    jclass fileClass = (*env)->GetObjectClass(env, filesDirObj);
    jmethodID getAbsolutePath = (*env)->GetMethodID(env, fileClass, "getAbsolutePath", "()Ljava/lang/String;");
    if (!getAbsolutePath) { (*env)->ExceptionClear(env); return NULL; }
    jstring absolutePath = (jstring)(*env)->CallObjectMethod(env, filesDirObj, getAbsolutePath);
    if (!absolutePath) { (*env)->ExceptionClear(env); return NULL; }
    const char* absolute_path_chars = (*env)->GetStringUTFChars(env, absolutePath, NULL);
    char* driver_path = NULL;
    if (absolute_path_chars) {
        if (asprintf(&driver_path, "%s/contents/adrenotools/%s/", absolute_path_chars, driver_name) == -1) {
            driver_path = NULL;
        }
        (*env)->ReleaseStringUTFChars(env, absolutePath, absolute_path_chars);
    }
    return driver_path;
}

static char* get_library_name(JNIEnv* env, jobject context, const char* driver_name) {
    if (!env || !context || !driver_name) return NULL;
    jclass adrenotoolsManager = (*env)->FindClass(env, "com/winlator/contents/AdrenotoolsManager");
    if (!adrenotoolsManager) { (*env)->ExceptionClear(env); return NULL; }
    jmethodID constructor = (*env)->GetMethodID(env, adrenotoolsManager, "<init>", "(Landroid/content/Context;)V");
    if (!constructor) { (*env)->ExceptionClear(env); return NULL; }
    jobject adrenotoolsManagerObj = (*env)->NewObject(env, adrenotoolsManager, constructor, context);
    if (!adrenotoolsManagerObj) { (*env)->ExceptionClear(env); return NULL; }
    jmethodID getLibraryName = (*env)->GetMethodID(env, adrenotoolsManager, "getLibraryName", "(Ljava/lang/String;)Ljava/lang/String;");
    if (!getLibraryName) { (*env)->ExceptionClear(env); return NULL; }
    jstring jDriverName = (*env)->NewStringUTF(env, driver_name);
    if (!jDriverName) { (*env)->ExceptionClear(env); return NULL; }
    jstring libraryName = (jstring)(*env)->CallObjectMethod(env, adrenotoolsManagerObj, getLibraryName, jDriverName);
    char* res = NULL;
    if (libraryName) {
        const char* utf = (*env)->GetStringUTFChars(env, libraryName, NULL);
        if (utf) {
            if (utf[0] != '\0') res = strdup(utf);
            (*env)->ReleaseStringUTFChars(env, libraryName, utf);
        }
    }
    return res;
}

static void* open_adrenotools_vulkan(JNIEnv* env, jobject context, const char* driver_name) {
    if (!driver_name || !driver_name[0] || strcmp(driver_name, "System") == 0 || !env || !context) {
        return NULL;
    }

    char* driver_path = get_driver_path(env, context, driver_name);
    if (!driver_path) return NULL;

    if (access(driver_path, F_OK) != 0) {
        free(driver_path);
        return NULL;
    }

    char* library_name = get_library_name(env, context, driver_name);
    if (!library_name) {
        library_name = strdup("vulkan.adreno.so");
    }

    char* native_lib_dir = get_native_library_dir(env, context);
    if (!native_lib_dir) {
        free(driver_path);
        free(library_name);
        return NULL;
    }

    char tmpdir[512];
    snprintf(tmpdir, sizeof(tmpdir), "%stemp", driver_path);
    mkdir(tmpdir, S_IRWXU | S_IRWXG);

    setenv("ADRENOTOOLS_DRIVER_PATH", driver_path, 1);
    setenv("ADRENOTOOLS_DRIVER_NAME", library_name, 1);
    setenv("ADRENOTOOLS_HOOKS_PATH", native_lib_dir, 1);

    const char* redirectDir = getenv("ADRENOTOOLS_REDIRECT_DIR");
    int featureFlags = ADRENOTOOLS_DRIVER_CUSTOM;
    if (redirectDir && redirectDir[0] != '\0') {
        featureFlags |= ADRENOTOOLS_DRIVER_FILE_REDIRECT;
    }

    void* handle = adrenotools_open_libvulkan(
        RTLD_LOCAL | RTLD_NOW,
        featureFlags,
        tmpdir,
        native_lib_dir,
        driver_path,
        library_name,
        (redirectDir && redirectDir[0] != '\0') ? redirectDir : NULL,
        NULL);

    free(driver_path);
    free(library_name);
    free(native_lib_dir);
    return handle;
}
#endif

static void* winlator_open_vulkan(JNIEnv* env, jobject context, const char* driver_name) {
#if defined(__aarch64__)
    if (driver_name && driver_name[0] != '\0' && strcmp(driver_name, "System") != 0 && env && context) {
        void* adreno_handle = open_adrenotools_vulkan(env, context, driver_name);
        if (adreno_handle) return adreno_handle;
    }
#else
    (void)env;
    (void)context;
    (void)driver_name;
#endif

    void* handle = dlopen("libvulkan.so", RTLD_LOCAL | RTLD_NOW);
    if (!handle) {
        handle = dlopen("libvulkan.so", RTLD_NOW);
    }
    return handle;
}

#define LOG_TAG "LsfgProbe"
#define PROBE_LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define PROBE_LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)

#define REQUIRED_FEATURES \
    (VK_FORMAT_FEATURE_STORAGE_IMAGE_BIT | VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT)

#define MAX_PROBE_DEVICES 8
#define MAX_PROBE_QUEUE_FAMILIES 16

typedef struct ProbeApi {
    PFN_vkGetInstanceProcAddr GetInstanceProcAddr;
    PFN_vkCreateInstance CreateInstance;
    PFN_vkDestroyInstance DestroyInstance;
    PFN_vkEnumeratePhysicalDevices EnumeratePhysicalDevices;
    PFN_vkGetPhysicalDeviceProperties GetPhysicalDeviceProperties;
    PFN_vkGetPhysicalDeviceFormatProperties GetPhysicalDeviceFormatProperties;
    PFN_vkGetPhysicalDeviceQueueFamilyProperties GetPhysicalDeviceQueueFamilyProperties;
    PFN_vkGetPhysicalDeviceFeatures2 GetPhysicalDeviceFeatures2;
    PFN_vkEnumerateDeviceExtensionProperties EnumerateDeviceExtensionProperties;
} ProbeApi;

static const VkFormat kRequiredFormats[] = {
    VK_FORMAT_R8G8B8A8_UNORM,
    VK_FORMAT_R8_UNORM,
    VK_FORMAT_R16G16B16A16_SFLOAT,
};

static bool load_probe_api(void* library, ProbeApi* api) {
    memset(api, 0, sizeof(*api));

    api->GetInstanceProcAddr = (PFN_vkGetInstanceProcAddr)dlsym(library, "vkGetInstanceProcAddr");
    if (!api->GetInstanceProcAddr) return false;

    api->CreateInstance =
        (PFN_vkCreateInstance)api->GetInstanceProcAddr(VK_NULL_HANDLE, "vkCreateInstance");
    return api->CreateInstance != NULL;
}

static bool load_instance_api(ProbeApi* api, VkInstance instance) {
    api->DestroyInstance =
        (PFN_vkDestroyInstance)api->GetInstanceProcAddr(instance, "vkDestroyInstance");
    api->EnumeratePhysicalDevices = (PFN_vkEnumeratePhysicalDevices)api->GetInstanceProcAddr(
        instance, "vkEnumeratePhysicalDevices");
    api->GetPhysicalDeviceProperties = (PFN_vkGetPhysicalDeviceProperties)api->GetInstanceProcAddr(
        instance, "vkGetPhysicalDeviceProperties");
    api->GetPhysicalDeviceFormatProperties =
        (PFN_vkGetPhysicalDeviceFormatProperties)api->GetInstanceProcAddr(
            instance, "vkGetPhysicalDeviceFormatProperties");
    api->GetPhysicalDeviceQueueFamilyProperties =
        (PFN_vkGetPhysicalDeviceQueueFamilyProperties)api->GetInstanceProcAddr(
            instance, "vkGetPhysicalDeviceQueueFamilyProperties");
    api->GetPhysicalDeviceFeatures2 = (PFN_vkGetPhysicalDeviceFeatures2)api->GetInstanceProcAddr(
        instance, "vkGetPhysicalDeviceFeatures2");
    api->EnumerateDeviceExtensionProperties =
        (PFN_vkEnumerateDeviceExtensionProperties)api->GetInstanceProcAddr(
            instance, "vkEnumerateDeviceExtensionProperties");

    return api->DestroyInstance && api->EnumeratePhysicalDevices &&
           api->GetPhysicalDeviceProperties && api->GetPhysicalDeviceFormatProperties &&
           api->GetPhysicalDeviceQueueFamilyProperties && api->GetPhysicalDeviceFeatures2;
}

static bool has_compute_queue(const ProbeApi* api, VkPhysicalDevice device) {
    uint32_t count = 0;
    api->GetPhysicalDeviceQueueFamilyProperties(device, &count, NULL);
    if (count == 0) return false;
    if (count > MAX_PROBE_QUEUE_FAMILIES) count = MAX_PROBE_QUEUE_FAMILIES;

    VkQueueFamilyProperties families[MAX_PROBE_QUEUE_FAMILIES];
    api->GetPhysicalDeviceQueueFamilyProperties(device, &count, families);

    for (uint32_t i = 0; i < count; i++) {
        if (families[i].queueCount > 0 && (families[i].queueFlags & VK_QUEUE_COMPUTE_BIT)) {
            return true;
        }
    }
    return false;
}

static bool has_required_formats(const ProbeApi* api, VkPhysicalDevice device) {
    const size_t format_count = sizeof(kRequiredFormats) / sizeof(kRequiredFormats[0]);
    for (size_t i = 0; i < format_count; i++) {
        VkFormatProperties properties;
        memset(&properties, 0, sizeof(properties));
        api->GetPhysicalDeviceFormatProperties(device, kRequiredFormats[i], &properties);
        if ((properties.optimalTilingFeatures & REQUIRED_FEATURES) != REQUIRED_FEATURES) {
            PROBE_LOGW("Format %d lacks storage or sampled support", (int)kRequiredFormats[i]);
            return false;
        }
    }
    return true;
}

static bool has_required_features(const ProbeApi* api, VkPhysicalDevice device) {
    VkPhysicalDeviceVulkanMemoryModelFeatures memory_model;
    memset(&memory_model, 0, sizeof(memory_model));
    memory_model.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_MEMORY_MODEL_FEATURES;

    VkPhysicalDeviceFeatures2 features;
    memset(&features, 0, sizeof(features));
    features.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2;
    features.pNext = &memory_model;

    api->GetPhysicalDeviceFeatures2(device, &features);

    if (!memory_model.vulkanMemoryModel) {
        PROBE_LOGW("vulkanMemoryModel unsupported; translated LSFG shaders require it");
        return false;
    }
    if (!features.features.shaderStorageImageWriteWithoutFormat) {
        PROBE_LOGW("shaderStorageImageWriteWithoutFormat unsupported");
        return false;
    }
    if (!features.features.shaderStorageImageExtendedFormats) {
        PROBE_LOGW("shaderStorageImageExtendedFormats unsupported");
        return false;
    }
    return true;
}

static bool has_graphics_queue(const ProbeApi* api, VkPhysicalDevice device) {
    uint32_t count = 0;
    api->GetPhysicalDeviceQueueFamilyProperties(device, &count, NULL);
    if (count == 0) return false;
    if (count > MAX_PROBE_QUEUE_FAMILIES) count = MAX_PROBE_QUEUE_FAMILIES;

    VkQueueFamilyProperties families[MAX_PROBE_QUEUE_FAMILIES];
    api->GetPhysicalDeviceQueueFamilyProperties(device, &count, families);

    for (uint32_t i = 0; i < count; i++) {
        if (families[i].queueCount > 0 && (families[i].queueFlags & VK_QUEUE_GRAPHICS_BIT)) {
            return true;
        }
    }
    return false;
}

static VkPhysicalDevice select_probe_device(const ProbeApi* api, VkInstance instance) {
    uint32_t device_count = 0;
    if (api->EnumeratePhysicalDevices(instance, &device_count, NULL) != VK_SUCCESS ||
        device_count == 0) {
        return VK_NULL_HANDLE;
    }
    if (device_count > MAX_PROBE_DEVICES) device_count = MAX_PROBE_DEVICES;

    VkPhysicalDevice devices[MAX_PROBE_DEVICES];
    if (api->EnumeratePhysicalDevices(instance, &device_count, devices) != VK_SUCCESS) {
        return VK_NULL_HANDLE;
    }

    for (uint32_t i = 0; i < device_count; i++) {
        if (has_graphics_queue(api, devices[i])) {
            return devices[i];
        }
    }
    return devices[0];
}

static bool probe_instance(ProbeApi* api, VkInstance instance) {
    VkPhysicalDevice device = select_probe_device(api, instance);
    if (device == VK_NULL_HANDLE) return false;

    VkPhysicalDeviceProperties properties;
    memset(&properties, 0, sizeof(properties));
    api->GetPhysicalDeviceProperties(device, &properties);

    if (properties.apiVersion < VK_API_VERSION_1_3) {
        PROBE_LOGW("%s reports Vulkan %u.%u; SPIR-V 1.6 modules need 1.3",
                   properties.deviceName, VK_API_VERSION_MAJOR(properties.apiVersion),
                   VK_API_VERSION_MINOR(properties.apiVersion));
        return false;
    }
    if (!has_compute_queue(api, device)) return false;
    if (!has_required_formats(api, device)) return false;
    if (!has_required_features(api, device)) return false;

    PROBE_LOGI("Frame generation supported on %s (Vulkan %u.%u)", properties.deviceName,
               VK_API_VERSION_MAJOR(properties.apiVersion),
               VK_API_VERSION_MINOR(properties.apiVersion));
    return true;
}

bool lsfg_probe_support(JNIEnv* env, jobject context, const char* driver_name) {
    void* library = winlator_open_vulkan(env, context, driver_name);
    if (!library) {
        PROBE_LOGW("Vulkan driver could not be opened for probing");
        return false;
    }

    ProbeApi api;
    if (!load_probe_api(library, &api)) {
        PROBE_LOGW("vkGetInstanceProcAddr unavailable in the selected driver");
        dlclose(library);
        return false;
    }

    VkApplicationInfo app_info;
    memset(&app_info, 0, sizeof(app_info));
    app_info.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
    app_info.pApplicationName = "GameNative";
    app_info.apiVersion = VK_API_VERSION_1_3;

    VkInstanceCreateInfo create_info;
    memset(&create_info, 0, sizeof(create_info));
    create_info.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    create_info.pApplicationInfo = &app_info;

    VkInstance instance = VK_NULL_HANDLE;
    if (api.CreateInstance(&create_info, NULL, &instance) != VK_SUCCESS) {
        app_info.apiVersion = VK_API_VERSION_1_1;
        if (api.CreateInstance(&create_info, NULL, &instance) != VK_SUCCESS) {
            PROBE_LOGW("vkCreateInstance failed during probe");
            dlclose(library);
            return false;
        }
    }

    bool supported = false;
    if (load_instance_api(&api, instance)) {
        supported = probe_instance(&api, instance);
    }

    if (api.DestroyInstance) api.DestroyInstance(instance, NULL);
    dlclose(library);

    if (!supported) PROBE_LOGI("Frame generation unsupported on this device");
    return supported;
}

static bool has_fp16_features(const ProbeApi* api, VkPhysicalDevice device) {
    VkPhysicalDeviceShaderFloat16Int8Features fp16;
    memset(&fp16, 0, sizeof(fp16));
    fp16.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_SHADER_FLOAT16_INT8_FEATURES;

    VkPhysicalDeviceFeatures2 features;
    memset(&features, 0, sizeof(features));
    features.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2;
    features.pNext = &fp16;

    api->GetPhysicalDeviceFeatures2(device, &features);
    if (fp16.shaderFloat16 != VK_TRUE) return false;

    VkPhysicalDeviceProperties props;
    memset(&props, 0, sizeof(props));
    api->GetPhysicalDeviceProperties(device, &props);
    if (props.apiVersion >= VK_API_VERSION_1_2) return true;

    if (!api->EnumerateDeviceExtensionProperties) return false;
    uint32_t count = 0;
    if (api->EnumerateDeviceExtensionProperties(device, NULL, &count, NULL) != VK_SUCCESS || count == 0) {
        return false;
    }
    VkExtensionProperties* exts = (VkExtensionProperties*)malloc(sizeof(VkExtensionProperties) * count);
    if (!exts) return false;
    bool has_ext = false;
    if (api->EnumerateDeviceExtensionProperties(device, NULL, &count, exts) == VK_SUCCESS) {
        for (uint32_t i = 0; i < count; i++) {
            if (strcmp(exts[i].extensionName, "VK_KHR_shader_float16_int8") == 0) {
                has_ext = true;
                break;
            }
        }
    }
    free(exts);
    return has_ext;
}

static bool probe_instance_fp16(ProbeApi* api, VkInstance instance) {
    VkPhysicalDevice device = select_probe_device(api, instance);
    if (device == VK_NULL_HANDLE) return false;
    return has_fp16_features(api, device);
}

bool lsfg_probe_fp16_support(JNIEnv* env, jobject context, const char* driver_name) {
    void* library = winlator_open_vulkan(env, context, driver_name);
    if (!library) return false;

    ProbeApi api;
    if (!load_probe_api(library, &api)) {
        dlclose(library);
        return false;
    }

    VkApplicationInfo app_info;
    memset(&app_info, 0, sizeof(app_info));
    app_info.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
    app_info.pApplicationName = "GameNative";
    app_info.apiVersion = VK_API_VERSION_1_3;

    VkInstanceCreateInfo create_info;
    memset(&create_info, 0, sizeof(create_info));
    create_info.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    create_info.pApplicationInfo = &app_info;

    VkInstance instance = VK_NULL_HANDLE;
    if (api.CreateInstance(&create_info, NULL, &instance) != VK_SUCCESS) {
        app_info.apiVersion = VK_API_VERSION_1_1;
        if (api.CreateInstance(&create_info, NULL, &instance) != VK_SUCCESS) {
            dlclose(library);
            return false;
        }
    }

    bool supported = false;
    if (load_instance_api(&api, instance)) {
        supported = probe_instance_fp16(&api, instance);
    }

    if (api.DestroyInstance) api.DestroyInstance(instance, NULL);
    dlclose(library);
    return supported;
}